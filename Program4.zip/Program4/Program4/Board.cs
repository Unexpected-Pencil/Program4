﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program4
{
    internal class Board
    {
        //initialize a 10x10 grid
        const int SIZE = 10;
        char[,] grid;
        //initialize round counter
        int maxRounds;
        int round;

        //Constructor that initializes the grid with '~' to represent water and sets round to 0
        //No input parameters
        public Board()
        {
            round = 0;
            grid = new char[SIZE,SIZE];
            for (int i = 0; i < SIZE; i++)
            {
                for (int j = 0; j < SIZE; j++)
                {
                    grid[i, j] = '~';

                }
            }
        }

        //Evaluates the player's answer
        //Input parameters: row and column of the player's guess
        //Returns: 'H' for hit and 'M' for miss
        public char EvaluateAnswer(int row, int col)
        {
            round++;
            if (grid[row, col] == 'S') 
            {
               grid [row, col] = 'H';
                return 'H';
            }
            else
            {
                grid[row, col] = 'M';
                return 'M';
            }
        }
        public void PlaceShip(int row, int col)
        {
            grid[row, col] = 'S';
        }
        public int MaxRounds // property for maxRounds
        {
            get { return maxRounds; }
            set { maxRounds = value; }
        }
        public int Round // property for Rounds
        {
            get { return round; }
            set { round = value; }
        }

    }

}
