﻿namespace Program4
{
    partial class BattleShipGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.introLabel = new System.Windows.Forms.Label();
            this.roundsBox = new System.Windows.Forms.TextBox();
            this.roundsLabel = new System.Windows.Forms.Label();
            this.startButton = new System.Windows.Forms.Button();
            this.cordsLabel = new System.Windows.Forms.Label();
            this.cordsBox = new System.Windows.Forms.TextBox();
            this.cordsButton = new System.Windows.Forms.Button();
            this.gamePanel = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // introLabel
            // 
            this.introLabel.AutoSize = true;
            this.introLabel.Font = new System.Drawing.Font("Elephant", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.introLabel.Location = new System.Drawing.Point(200, 99);
            this.introLabel.Name = "introLabel";
            this.introLabel.Size = new System.Drawing.Size(401, 41);
            this.introLabel.TabIndex = 0;
            this.introLabel.Text = "Welcome to Battleship";
            // 
            // roundsBox
            // 
            this.roundsBox.Font = new System.Drawing.Font("Elephant", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundsBox.Location = new System.Drawing.Point(407, 143);
            this.roundsBox.Name = "roundsBox";
            this.roundsBox.Size = new System.Drawing.Size(76, 33);
            this.roundsBox.TabIndex = 1;
            // 
            // roundsLabel
            // 
            this.roundsLabel.AutoSize = true;
            this.roundsLabel.Font = new System.Drawing.Font("Elephant", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roundsLabel.Location = new System.Drawing.Point(192, 150);
            this.roundsLabel.Name = "roundsLabel";
            this.roundsLabel.Size = new System.Drawing.Size(209, 26);
            this.roundsLabel.TabIndex = 2;
            this.roundsLabel.Text = "How Many Rounds:";
            // 
            // startButton
            // 
            this.startButton.Font = new System.Drawing.Font("Elephant", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startButton.Location = new System.Drawing.Point(489, 143);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(107, 33);
            this.startButton.TabIndex = 3;
            this.startButton.Text = "START";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // cordsLabel
            // 
            this.cordsLabel.AutoSize = true;
            this.cordsLabel.Location = new System.Drawing.Point(45, 548);
            this.cordsLabel.Name = "cordsLabel";
            this.cordsLabel.Size = new System.Drawing.Size(142, 20);
            this.cordsLabel.TabIndex = 4;
            this.cordsLabel.Text = "Enter Coordinates:";
            this.cordsLabel.Visible = false;
            // 
            // cordsBox
            // 
            this.cordsBox.Location = new System.Drawing.Point(193, 542);
            this.cordsBox.Name = "cordsBox";
            this.cordsBox.Size = new System.Drawing.Size(100, 26);
            this.cordsBox.TabIndex = 5;
            this.cordsBox.Visible = false;
            // 
            // cordsButton
            // 
            this.cordsButton.Location = new System.Drawing.Point(299, 545);
            this.cordsButton.Name = "cordsButton";
            this.cordsButton.Size = new System.Drawing.Size(75, 26);
            this.cordsButton.TabIndex = 7;
            this.cordsButton.Text = "GO";
            this.cordsButton.UseVisualStyleBackColor = true;
            this.cordsButton.Visible = false;
            this.cordsButton.Click += new System.EventHandler(this.cordsButton_Click);
            // 
            // gamePanel
            // 
            this.gamePanel.Location = new System.Drawing.Point(122, 25);
            this.gamePanel.Name = "gamePanel";
            this.gamePanel.Size = new System.Drawing.Size(200, 100);
            this.gamePanel.TabIndex = 8;
            this.gamePanel.Visible = false;
            // 
            // BattleShipGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 630);
            this.Controls.Add(this.gamePanel);
            this.Controls.Add(this.cordsButton);
            this.Controls.Add(this.cordsBox);
            this.Controls.Add(this.cordsLabel);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.roundsLabel);
            this.Controls.Add(this.roundsBox);
            this.Controls.Add(this.introLabel);
            this.Name = "BattleShipGame";
            this.Text = "Battleship";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label introLabel;
        private System.Windows.Forms.TextBox roundsBox;
        private System.Windows.Forms.Label roundsLabel;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label cordsLabel;
        private System.Windows.Forms.TextBox cordsBox;
        private System.Windows.Forms.Button cordsButton;
        private System.Windows.Forms.Panel gamePanel;
    }
}

