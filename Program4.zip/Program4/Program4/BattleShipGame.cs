﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program4
{
    public partial class BattleShipGame : Form
    {
        Board board;
        //2D array to hold labels representing the game board so they don't have to be manually created
        private Label[,] boardLabels = new Label[10, 10]; 
        private const int CELLSIZE = 35; //size of the cells in the game board
        public BattleShipGame()
        {
            InitializeComponent();
            board = new Board();//instantiate the game Board object


        }
        //Method to create the game board by adding labels to a panel
        //Sets the text, color, size, location, and alignment of each label
        private void createBoard()
        {
            for (int row = 0; row < 10; row++)
            {
                for (int col = 0; col < 10; col++)
                {
                    Label cellLabel = new Label();
                    cellLabel.Text = "~";
                    cellLabel.ForeColor = Color.Blue;
                    cellLabel.Size = new Size(CELLSIZE, CELLSIZE);
                    cellLabel.Location = new Point(col * CELLSIZE, row * CELLSIZE);
                    cellLabel.TextAlign = ContentAlignment.MiddleCenter;
                    gamePanel.Controls.Add(cellLabel);
                    boardLabels[row, col] = cellLabel;
                }
            }
            gamePanel.Size = new Size(10 * CELLSIZE, 10 * CELLSIZE);
        }
        

        //Event handler for when player starts the game
        //Creates a new Board object and sets the MaxRounds property based on user input
        //Hides all intro controls and then creates and displays the game board
        private void startButton_Click(object sender, EventArgs e)
        {
            board.MaxRounds = int.Parse(roundsBox.Text); 
            roundsBox.Visible = false;
            roundsLabel.Visible = false;
            startButton.Visible = false;
            introLabel.Visible = false;
            createBoard(); //calls createBoard method to create the game board
            cordsBox.Visible = true;
            cordsLabel.Visible = true;
            cordsButton.Visible = true;
            gamePanel.Visible = true;


        }

        //Event handler for when player submits their guess
        //Parses the input from cordsBox to get the row and column of the guess
        //Calls EvaluateAnswer method on the Board object to determine if the guess is a hit or miss
        //Updates the corresponding label on the game board to show a hit (red) or miss (black)
        private void cordsButton_Click(object sender, EventArgs e)
        {
            int guessRow = int.Parse(cordsBox.Text[0].ToString());
            int guessCol = int.Parse(cordsBox.Text[3].ToString());
            if (guessRow >= 0 && guessRow <= 9 && guessCol >= 0 && guessCol <= 9)
            {
                char result = board.EvaluateAnswer(guessRow, guessCol);
                boardLabels[guessRow, guessCol].ForeColor = (result == 'H') ? Color.Red : Color.Black;
            }
            else {
        }
    }
}
